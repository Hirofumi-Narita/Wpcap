#include<pcap.h>
#include"Captuer.h"

char errbuf[PCAP_ERRBUF_SIZE];
pcap_t *fp = NULL;

//------------------------------------------------------------------------
// �l�b�g���[�N�A�_�v�^�[�̓ǂݍ��� 
//------------------------------------------------------------------------
int LoadAdapter(unsigned long AddressList[MAX_ADAPTER], char NameList[MAX_ADAPTER][1024], int *n) {
	pcap_if_t *alldevs;				//�f�o�C�X��ۑ�
	pcap_if_t *d;					//�ꎞ�ϐ�
								
	/* �A�_�v�^�[�̓ǂݍ��� */
	if (pcap_findalldevs(&alldevs, errbuf) == -1){
		return false;
	}

	/* ���X�g�̕ۑ� */
	for (d = alldevs; d ;d = d->next) {
		if (d->addresses != NULL) {
			sockaddr_in *sa = (sockaddr_in*)d->addresses->addr;
			AddressList[*n] = sa->sin_addr.s_addr;
			strcpy(NameList[*n], d->name);
			(*n)++;
		}
	}

	/* �I������ */
	pcap_freealldevs(alldevs);

	return true;
}

//------------------------------------------------------------------------
// Adapter�̓ǂݍ��� 
//------------------------------------------------------------------------
int OpenAdapter(char *AdapterName) {
	if (fp != NULL) {
		return false;
	}

	int timeout = 10; //�^�C���A�E�g����(ms)
	if ((fp = pcap_open_live(AdapterName, MAX_PACKET_SIZE, true, timeout, errbuf)) == NULL) {
		return false;
	}

	return true;
}

//------------------------------------------------------------------------
// Adapter�̉��
//------------------------------------------------------------------------
int CloseAdapter() {
	if (fp == NULL) {
		return false;
	}
	pcap_close(fp);
	fp = NULL;
	return true;
}

//------------------------------------------------------------------------
// �p�P�b�g�̎擾
//------------------------------------------------------------------------
int GetPacket(unsigned char *Buffer) {
	if (fp == NULL) {
		return false;
	}

	int ret;
	const u_char *pkt_data;
	struct pcap_pkthdr *pkt_header;
	if (0 <= (ret = pcap_next_ex(fp, &pkt_header, &pkt_data))) {
		if (ret == 1) {
			unsigned long n = pkt_header->caplen;
			memcpy(Buffer, pkt_data, n);
		}
		return true;
	}
	return false;
}